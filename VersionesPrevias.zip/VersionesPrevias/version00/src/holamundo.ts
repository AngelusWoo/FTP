let mensaje : string = "Desarrollo de Videojuegos con Phaser";
let version : number = 5;
let mensaje2 : string = " y TypeScript";
console.log(mensaje + version + mensaje2 + ". Hello");