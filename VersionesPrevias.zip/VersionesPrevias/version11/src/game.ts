import * as Phaser from 'phaser';
import Configuracion from './configuracion';

window.addEventListener('load', ()=>{
    const game = new Phaser.Game(Configuracion);
});
